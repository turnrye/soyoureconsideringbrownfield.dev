self.__precacheManifest = [
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "/./fonts/Foundation.ttf"
  },
  {
    "revision": "a0cbab71bd27ce4271cc",
    "url": "/static/js/app.f7793ba0.chunk.js"
  },
  {
    "revision": "27b8ebe8673b4b3eaf61",
    "url": "/static/js/runtime~app.f53f8695.js"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "/./fonts/Ionicons.ttf"
  },
  {
    "revision": "04e85b411eaa652156c15e2dbf965077",
    "url": "/index.html"
  },
  {
    "revision": "4cf1fe2e0b2e7409d491f1e6f44fb5cf",
    "url": "/manifest.json"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "/serve.json"
  },
  {
    "revision": "53896a59266eae5ff726",
    "url": "/static/js/2.d2b63845.chunk.js"
  },
  {
    "revision": "7a7bc7ead25db795e58b336f04d2624c",
    "url": "/favicon.ico"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "/./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "5a293a273bee8d740a045d9922b9a9ae",
    "url": "/./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "872545dde71de3842234bf6afe80c4cb",
    "url": "/./fonts/FontAwesome5_Solid.ttf"
  },
  {
    "revision": "c6aef942e3668158ec29d4adcb2e768f",
    "url": "/./fonts/FontAwesome5_Brands.ttf"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/./fonts/FontAwesome.ttf"
  },
  {
    "revision": "6beba7e6834963f7f171d3bdd075c915",
    "url": "/./fonts/Feather.ttf"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "/./fonts/Entypo.ttf"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "/./fonts/AntDesign.ttf"
  }
];